package com.ritik.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private TextView status, transcript, reply;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,11,22));
        getWindow().setNavigationBarColor(Color.rgb(5,11,22));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(24, 28, 24, 24);
        page.setBackgroundColor(Color.rgb(5,11,22));

        TextView brand = new TextView(this);
        brand.setText("J.A.R.V.I.S.");
        brand.setTextColor(Color.rgb(71,232,255));
        brand.setTextSize(27);
        brand.setGravity(Gravity.CENTER);
        brand.setLetterSpacing(0.18f);
        page.addView(brand, new LinearLayout.LayoutParams(-1, 54));

        TextView sub = new TextView(this);
        sub.setText("PERSONAL AI • HOLOGRAPHIC INTERFACE");
        sub.setTextColor(Color.rgb(125,190,210));
        sub.setTextSize(10);
        sub.setGravity(Gravity.CENTER);
        page.addView(sub);

        HoloView holo = new HoloView(this);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(280, 280);
        hp.topMargin = 20; hp.bottomMargin = 12;
        page.addView(holo, hp);

        status = makeText("SYSTEM ONLINE • READY");
        status.setTextColor(Color.rgb(71,232,255));
        page.addView(status);

        transcript = makeText("You: Say “Hello JARVIS” or tap the microphone.");
        transcript.setTextColor(Color.WHITE);
        transcript.setPadding(12, 16, 12, 8);
        page.addView(transcript);

        reply = makeText("JARVIS: Hello. I'm ready to assist you.");
        reply.setTextColor(Color.rgb(160,220,235));
        reply.setPadding(12, 4, 12, 16);
        page.addView(reply);

        Button mic = new Button(this);
        mic.setText("🎙  TALK TO JARVIS");
        mic.setTextColor(Color.rgb(5,11,22));
        mic.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(71,232,255)));
        page.addView(mic, new LinearLayout.LayoutParams(-1, 58));
        mic.setOnClickListener(v -> startListening());

        Button settings = new Button(this);
        settings.setText("OPEN PHONE SETTINGS");
        settings.setTextColor(Color.rgb(71,232,255));
        settings.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(17,35,52)));
        page.addView(settings, new LinearLayout.LayoutParams(-1, 52));
        settings.setOnClickListener(v -> {
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); }
            catch (Exception e) { say("I could not open Settings."); }
        });

        TextView note = makeText("This starter version uses on-device Android features. Some actions require your permission.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(11);
        note.setPadding(10, 18, 10, 0);
        page.addView(note);

        setContentView(page);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setLanguage(Locale.US);
                // Prefer an installed voice whose name suggests a female voice, if available.
                try {
                    for (android.speech.tts.Voice voice : tts.getVoices()) {
                        String n = voice.getName().toLowerCase(Locale.ROOT);
                        if (n.contains("female") && voice.getLocale().getLanguage().equals("en")) {
                            tts.setVoice(voice); break;
                        }
                    }
                } catch (Exception ignored) {}
            }
        });

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { status.setText("LISTENING…"); }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float r) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { status.setText("THINKING…"); }
                public void onError(int e) { status.setText("READY • TRY AGAIN"); }
                public void onResults(Bundle b) {
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) handleCommand(r.get(0));
                }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int t, Bundle p) {}
            });
        }
    }

    private TextView makeText(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(14); t.setGravity(Gravity.CENTER);
        return t;
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
            return;
        }
        if (recognizer == null) { say("Speech recognition is not available on this phone."); return; }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS");
        recognizer.startListening(i);
    }

    private void handleCommand(String command) {
        transcript.setText("You: " + command);
        String c = command.toLowerCase(Locale.ROOT);
        String answer;
        if (c.contains("setting") || c.contains("सेटिंग")) {
            answer = "Opening your phone settings.";
            say(answer);
            startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            return;
        } else if (c.contains("camera") || c.contains("कैमरा")) {
            answer = "Opening camera.";
            say(answer);
            try { startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); }
            catch (Exception e) { say("Camera app is not available."); }
            return;
        } else if (c.contains("youtube")) {
            answer = "Opening YouTube.";
            say(answer);
            openPackage("com.google.android.youtube");
            return;
        } else if (c.contains("chrome") || c.contains("browser")) {
            answer = "Opening your browser.";
            say(answer);
            try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))); }
            catch (Exception e) { say("Browser not available."); }
            return;
        } else if (c.contains("time") || c.contains("समय") || c.contains("बजे")) {
            answer = "The time is " + new java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date());
        } else if (c.contains("hello") || c.contains("नमस्ते") || c.contains("हेलो")) {
            answer = "Hello! I am JARVIS. How may I help you?";
        } else {
            answer = "I heard you say: " + command + ". My starter brain can open Settings, Camera, YouTube and your browser. More AI features can be connected next.";
        }
        reply.setText("JARVIS: " + answer);
        status.setText("SYSTEM ONLINE • READY");
        say(answer);
    }

    private void openPackage(String pkg) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) startActivity(launch);
            else say("That app is not installed.");
        } catch (Exception e) { say("I could not open that app."); }
    }

    private void say(String words) {
        reply.setText("JARVIS: " + words);
        if (ttsReady) tts.speak(words, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 7 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else status.setText("MIC PERMISSION NEEDED");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    static class HoloView extends View {
        Paint p = new Paint(3);
        HoloView(Activity a) { super(a); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float x=getWidth()/2f, y=getHeight()/2f;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
            for(int i=0;i<5;i++){
                p.setColor(Color.argb(190-i*25,71,232,255));
                p.setShadowLayer(18,0,0,Color.rgb(30,190,255));
                c.drawCircle(x,y,48+i*20,p);
            }
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(71,232,255));
            c.drawCircle(x,y,7,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1);
            c.drawArc(x-105,y-105,x+105,y+105,25,95,false,p);
            c.drawArc(x-105,y-105,x+105,y+105,205,95,false,p);
            p.setTextSize(11); p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(130,235,255));
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText("AI CORE",x,y+4,p);
        }
    }
}
