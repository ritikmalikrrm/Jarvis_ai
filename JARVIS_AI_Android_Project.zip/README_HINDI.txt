JARVIS AI - Android starter project

Is version mein:
- Futuristic hologram style screen
- Android speech recognition (microphone permission ke baad)
- Android Text-to-Speech (device par available voice)
- Voice commands: Settings, Camera, YouTube, browser, time, hello
- Ye abhi full ChatGPT-style AI nahi hai. AI brain ke liye baad mein secure backend/API connect karna hoga.
- Android security ke kaaran phone ke har feature ko bina permission control nahi kiya ja sakta.

APK banane ke liye:
1. Is ZIP ko extract karein.
2. Android Studio mein folder open karein.
3. Gradle sync hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Sirf Android phone se build karne ke liye:
- Is project ko GitHub par upload karke Android build workflow configure karna hoga, ya kisi Android cloud build service ka use karna hoga.
- Kisi bhi website ko apna Google password/API key na dein.
